package com.edu.bh.configure;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class UserServiceConfig implements WebMvcConfigurer {

	@Bean
	public FilterRegistrationBean<UserServiceFilter> loggingFilter(){
		FilterRegistrationBean<UserServiceFilter> registrationBean = new FilterRegistrationBean<>();
		registrationBean.setFilter(new UserServiceFilter());
		registrationBean.addUrlPatterns("/*");
		return registrationBean;
	}
}
