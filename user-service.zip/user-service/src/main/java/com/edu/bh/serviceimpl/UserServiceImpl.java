package com.edu.bh.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.bh.entity.SuperUser;
import com.edu.bh.entity.Users;
import com.edu.bh.repository.UsersRepo;
import com.edu.bh.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UsersRepo userRepo;

	@Override
	public List<Users> getAllUsers() {
		return userRepo.findAll();
	}

	@Override
	public String adddUser(Users user) {
		Users result = userRepo.save(user);
		if (result == null) {
			return "Failed to add data";
		} else {
			return "Data added successfully";
		}
	}

	@Override
	public void modifyUser(Users user) {
		// TODO Auto-generated method stub
	}

	@Override
	public void deleteUser(Long id) {
		userRepo.deleteById(id);
	}

	@Override
	public List<SuperUser> getAllUsersWithRole() {
		List<SuperUser> users = new ArrayList<>();
		userRepo.findAll().forEach(user -> {
			SuperUser superuser = new SuperUser("Super User", user);
			users.add(superuser);
		});
		return users;

	}

	@Override
	public Users getUserById(Long id) {
		Optional<Users> result = userRepo.findById(id);
		Users res = result.get();
		return res;
	}

}
