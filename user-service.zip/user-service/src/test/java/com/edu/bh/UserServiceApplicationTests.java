package com.edu.bh;

import org.springframework.boot.test.context.SpringBootTest;

//@RunWith(SpringRunner.class)
@SpringBootTest
public class UserServiceApplicationTests {

//	@Test
//	public void contextLoads() {
//	}

}
